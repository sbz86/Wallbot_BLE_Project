/*

Copyright (c) 2012-2014 RedBearLab
Modified by sz86 2017

Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
and associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE 
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
#include <stdlib.h>
#include "mbed.h"
#include "ble/BLE.h"
#include "Servo.h"
#include "GattCallbackParamTypes.h"
#include "TB6612.h"

#define BLE_UUID_TXRX_SERVICE            0x0000 /**< The UUID of the Nordic UART Service. */
#define BLE_UUID_TX_CHARACTERISTIC       0x0002 /**< The UUID of the TX Characteristic. */
#define BLE_UUIDS_RX_CHARACTERISTIC      0x0003 /**< The UUID of the RX Characteristic. */

#define TXRX_BUF_LEN                     32

#define DIGITAL_IN_PIN                   P0_5   //A4
#define PWMR_PIN                         P0_28  //D6
#define PWML_PIN                         P0_29  //D10
#define ANALOG_IN_PIN                    P0_6   //A5

BLE             ble;

DigitalOut      LED_2(P0_19);
DigitalOut      LED_1(P0_18);
DigitalIn       BUTTON(DIGITAL_IN_PIN);
TB6612          PWMR(PWMR_PIN,P0_30,P0_0);
TB6612          PWML(PWML_PIN,P0_23,P0_24);
AnalogIn        ANALOG(ANALOG_IN_PIN);

Serial pc(USBTX, USBRX);

static uint8_t analog_enabled = 0;
static uint8_t old_state = 0;

/*
    variables added by sz86
*/
///////////////////////////////////////////////////////////////////////
int defaultMode = 0;
int readable3 = 1;          //states whether the pattern is readable or not
int avenue = 0;             //states the current avenue
int controltaken = 0;       //states whether the control is taken by the robot
enum Colour{Black, White};  //the colour of the line below a sensor
Colour sensor2;             //the colour below sensor 2
Colour sensor3;             //the colour below sensor 3
int sensor2_st = 0;         //the state taken from sensor 2
int sensor3_st = 0;         //the state taken from sensor 3
int result = 0;             //the calculated result from the pattern
int reading = 0;            //states whether the pattern is being read or not
double power = 0;           //used to calculate the result
AnalogIn fsen1(P0_2);       //sensor 1
AnalogIn fsen2(P0_3);       //sensor 2
AnalogIn fsen3(P0_4);       //sensor 3
AnalogIn fsen4(P0_5);       //sensor 4

static uint8_t rx_len=32;
DigitalIn   sw1(P0_16);     //button sw1
DigitalIn   sw2(P0_17);     //button sw2
int controlandreading = 0;  //used in Control while Reading mode
int exitfollowing = 0;      //used to exit the Following mode

///////////////////////////////////////////////////////////////////////

// The Nordic UART Service
static const uint8_t uart_base_uuid[] = {0x71, 0x3D, 0, 0, 0x50, 0x3E, 0x4C, 0x75, 0xBA, 0x94, 0x31, 0x48, 0xF1, 0x8D, 0x94, 0x1E};
static const uint8_t uart_tx_uuid[]   = {0x71, 0x3D, 0, 3, 0x50, 0x3E, 0x4C, 0x75, 0xBA, 0x94, 0x31, 0x48, 0xF1, 0x8D, 0x94, 0x1E};
static const uint8_t uart_rx_uuid[]   = {0x71, 0x3D, 0, 2, 0x50, 0x3E, 0x4C, 0x75, 0xBA, 0x94, 0x31, 0x48, 0xF1, 0x8D, 0x94, 0x1E};
static const uint8_t uart_base_uuid_rev[] = {0x1E, 0x94, 0x8D, 0xF1, 0x48, 0x31, 0x94, 0xBA, 0x75, 0x4C, 0x3E, 0x50, 0, 0, 0x3D, 0x71};


uint8_t txPayload[TXRX_BUF_LEN] = {0,};
uint8_t rxPayload[TXRX_BUF_LEN] = {0,};


GattCharacteristic  txCharacteristic (uart_tx_uuid, txPayload, 1, TXRX_BUF_LEN, GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE | GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE_WITHOUT_RESPONSE);
                                      
GattCharacteristic  rxCharacteristic (uart_rx_uuid, rxPayload, 1, TXRX_BUF_LEN, GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_NOTIFY);
                                      
GattCharacteristic *uartChars[] = {&txCharacteristic, &rxCharacteristic};

GattService         uartService(uart_base_uuid, uartChars, sizeof(uartChars) / sizeof(GattCharacteristic *));



void disconnectionCallback(const Gap::DisconnectionCallbackParams_t *params)
{
    pc.printf("Disconnected \r\n");
    pc.printf("Restart advertising \r\n");
    ble.startAdvertising();
}

/*
    The method to handle a pack received from BLE. Edited by sz86
*/
void WrittenHandler(const GattWriteCallbackParams *Handler)
{   
    uint8_t buf[TXRX_BUF_LEN];
    uint16_t bytesRead, index;
    //if the robot is allowed to read a pattern
    if(readable3 == 1)
    {
        if (Handler->handle == txCharacteristic.getValueAttribute().getHandle()) 
        {
            ble.readCharacteristicValue(txCharacteristic.getValueAttribute().getHandle(), buf, &bytesRead);
            memset(txPayload, 0, TXRX_BUF_LEN);
            memcpy(txPayload, buf, TXRX_BUF_LEN);       
        
            for(index=0; index<bytesRead; index++)
                pc.putc(buf[index]);
            
            //if the button in the app is pressed
            if(buf[0] == 0x01)
            {
                defaultMode = 1;
            }
            else if(buf[0] == 0xA0)
            {
                if(buf[1] == 0x01)
                    analog_enabled = 1;
                else
                    analog_enabled = 0;
            }
            
            //if the right controller in the app is used
            else if(buf[0] == 0x02 && controltaken == 0)
            {
                if ((float)buf[1] <=135 && (float)buf[1] >=115){
                    PWMR = 0;
                }else if((float)buf[1] >135){
                    float value = ((float)buf[1] - 135)/80;
                    PWMR = value;
                }else{
                    float value = ((float)buf[1] - 115)/80;
                    PWMR = value;
                }
            }
            
            //if the left controller in the app is used
            else if(buf[0] == 0x03 && controltaken == 0)
            {
                if ((float)buf[1] <=135 && (float)buf[1] >=115){
                    PWML = 0;
                }else if((float)buf[1] >135){
                    float value = ((float)buf[1] - 135)/80;
                    PWML = value;
                }else{
                    float value = ((float)buf[1] - 115)/80;
                    PWML = value;
                }
            }
            else if(buf[0] == 0x04)
            {
                analog_enabled = 0;
                PWMR = 0;
                PWML = 0;
                LED_2 = 1;
                old_state = 0;    
            }

        }
    }else //if the robot is not allowed to read a patter
    {
        if (Handler->handle == txCharacteristic.getValueAttribute().getHandle()) 
        {
            ble.readCharacteristicValue(txCharacteristic.getValueAttribute().getHandle(), buf, &bytesRead);
            memset(txPayload, 0, TXRX_BUF_LEN);
            memcpy(txPayload, buf, TXRX_BUF_LEN);       
        
            for(index=0; index<bytesRead; index++)
                pc.putc(buf[index]);
            
            //if the button in the app is pressed
            if(buf[0] == 0x01)
            {
                if(buf[1] == 0x00 && buf[2] == 0x00)
                    defaultMode = 1;
            }
        }
    }
}
void m_status_check_handle(void)
{   
    uint8_t buf[3];
    if (analog_enabled)  // if analog reading enabled
    {
        // Read and send out
        float s = ANALOG;
        uint16_t value = s*1024; 
        buf[0] = (0x0B);
        buf[1] = (value >> 8);
        buf[2] = (value);
        ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), buf, 3); 
    }
    
    // If digital in changes, report the state
    if (BUTTON != old_state)
    {
        old_state = BUTTON;
        
        if (BUTTON == 1)
        {
            buf[0] = (0x0A);
            buf[1] = (0x01);
            buf[2] = (0x00);    
            ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), buf, 3); 
        }
        else
        {
            buf[0] = (0x0A);
            buf[1] = (0x00);
            buf[2] = (0x00);
           ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), buf, 3); 
        }
    }
}

int get_fsen(int num)
{
    switch(num)
    {
    case 0: 
        return((int)fsen1.read_u16());
    case 1: 
        return((int)fsen2.read_u16());
    case 2: 
        return((int)fsen3.read_u16());
    case 3: 
        return((int)fsen4.read_u16());
    }
    return(0);
}

/*
    the rest of the code of methods and variables is edited or added by sz86
*/

/*
    the method returns 1 if the robot sees a black line and 0 otherwise
    the parameter decides the sensor from the 4 sensors
*/
int get_line(int num)
{
    int in = get_fsen(num);
    int ret = 0;
    if(num == 3)
        {
        if(in>920) //because sensor 3 has some issues, the number is higher
            ret = 1;
        }
    else
        if(in>700)
            ret = 1;
        
    return(ret);
}

/*
    The method returns a number according to the reading of the four sensors
*/
int readLine(void){
    int n = get_line(0) ? 1 : 0;
        n |= get_line(1) ? 2 : 0;
        n |= get_line(2) ? 4 : 0;
        n |= get_line(3) ? 8 : 0;
    return n;
}

/*
    makes the states of the sensors that read the patterns zeros
*/
void zerostates(void)
{
    sensor2_st = 0;
    sensor3_st = 0;
}

/*
    Resets all the states.
*/
void statesReset(void)
{
    sensor2_st = 0;
    sensor3_st = 0;
    sensor2 = White;
    sensor3 = White;
    result = 0;
    reading = 0;
    power = 0;
    avenue = 0;
}

/*
    returns a random number from 0 to 9
*/
int randomDirection(void)
{
    return rand() % 10;
}

/*
    turns 90 degree to the right or left according to the parameter
    if parameter "dir" is 1, then turn right
    if "dir" is 0, then turn left
*/
void turn90(int dir)
{
    if(dir == 1) // turn right
    {
        PWMR = -0.7;
        PWML = 0.7;
        wait(0.7);
    }else if(dir == 0) // turn left
    {
        PWMR = 0.7;
        PWML = -0.7;
        wait(0.7);
    }
}

/*
    follow a road without reading patterns
*/
void followNoReadings(void)
{
    PWMR = (fsen1.read_u16() + 500)/1000.0;
    PWML = (fsen4.read_u16() - 100)/1000.0; //sensor 3 has some issues the method is different
}

/*
    the action of parking the robot according to the road created
*/
void parking(void)
{
    turn90(0);
    LED_1 = 0;
    LED_2 = 0;
    while((readLine() & 6) != 6)
    {
        followNoReadings();
    }
    PWMR = 1;
    PWML = -1;
    wait(1.3);
    PWMR = 0;
    PWML = 0;
    LED_1 = 1;
    LED_2 = 1;
}

/*
    The method does an action according to the pattern read
*/
void doAction(void)
{
    switch(result)
    {
        case 1: //if the pattern is 01
            int dir = randomDirection();
            if(dir > 4)
                dir = 1;
            else
                dir = 0;
            
            if(dir == 1){
                uint8_t rx_buf[] = "Approaching 1st E AV";
                ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf, sizeof("Approaching 1st E AV"));
            }
            else{
                uint8_t rx_buf[] = "Approaching 1st W AV";
                ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf, sizeof("Approaching 1st W AV"));
            }
            if(!controlandreading) //if the robot is reading and doing actions
            {
                while((readLine() & 6) != 6) //do not do the action until a black line is found
                {
                    followNoReadings();
                }
                turn90(dir);
            }
            avenue = avenue + 1;
            break;
        case 2: //if the pattern is 10
            if(avenue == 1){
                uint8_t rx_buf1[] = "Approaching 2nd W AV";
                ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf1, sizeof("Approaching 2nd W AV"));
            }
            else{
                uint8_t rx_buf1[] = "Approaching 3rd W AV";
                ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf1, sizeof("Approaching 3rd W AV"));
            }
            if(!controlandreading) //if the robot is reading and doing actions
            {
                while((readLine() & 6) != 6) //do not do the action until a black line is found
                {
                    followNoReadings();
                }
                turn90(1);
            }
            avenue = avenue + 1;
            break;
        case 3: //if the pattern is 11
            if(avenue == 1){
                uint8_t rx_buf2[] = "Approaching 2nd E AV";
                ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf2, sizeof("Approaching 2nd E AV"));
            }
            else{
                uint8_t rx_buf2[] = "Approaching 3rd E AV";
                ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf2, sizeof("Approaching 3rd E AV"));
            }
            if(!controlandreading) //if the robot is reading and doing actions
            {
                while((readLine() & 6) != 6) //do not do the action until a black line is found
                {
                    followNoReadings();
                }
                turn90(0);
            }
            avenue = avenue + 1;
            break;
        case 4: //if the pattern is 100
            uint8_t rx_buf3[] = "Parking";
            ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf3, sizeof("Parking"));
            if(!controlandreading) //if the robot is reading and doing actions
            {
                while((readLine() & 6) != 6) //do not do the action until a black line is found
                {
                    followNoReadings();
                }
                parking();
                exitfollowing = 1;
            }
            break;
        case 5: //if the pattern is 101
            uint8_t rx_buf4[] = "Stopped";
            ble.updateCharacteristicValue(rxCharacteristic.getValueAttribute().getHandle(), rx_buf4, sizeof("Stopped"));
            if(!controlandreading) //if the robot is reading and doing actions
            {
                PWMR = 0;
                PWML = 0;
                exitfollowing = 1;
            }
            break;
        default:
            break;
    }
    result = 0; //set the result back to zero for a new pattern
}

/*
    The method records the line that is read and add it to the result accordingly
*/
void record(void)
{
    if(sensor2 == White && sensor3 == White)
    {
        if(sensor2_st == 1 && sensor3_st == 0)
        {
            result += 1 * pow(2,power);
            power++;
            zerostates();
        }
        else if(sensor2_st == 0 && sensor3_st == 1)
        {
            power++;
            zerostates();
        }
    }
}

/*
    This method checks if the beginning or the end of the pattern is recognized
    Also, it does the action of the pattern if it is the end of the pattern
*/
void checkreading(void)
{
    if(sensor2 == White && sensor3 == White)
    {
        if(sensor2_st == 1 && sensor3_st == 1 && reading == 0)
        {
            reading = 1;
            power = 0;
            zerostates();
        }
        else if(sensor2_st == 1 && sensor3_st == 1 && reading == 1)
        {
            reading = 0;
            zerostates();
            doAction();
        }
        else if(reading == 0)
            zerostates();
    }
}

/*
    The method gives the right colour to the sensor, either white or black.
    It sets the state to one if the sensor changes from black to white.
*/
void checkline(int n)
{
    if((n&4) == 4)
    {
        if(sensor3 == White)
            sensor3 = Black;
    }
    else
    {
        if(sensor3 == Black)
        {
            sensor3 = White;
            sensor3_st = 1;
        }
    }
    if((n&2) == 2)
    {
        if(sensor2 == White)
            sensor2 = Black;
    }
    else
    {
        if(sensor2 == Black)
        {
            sensor2 = White;
            sensor2_st = 1;
        }
    }
    checkreading();
    if(reading)
        record();
}

/*
    This method allow the robot to follow the road.
    It also checks the line read by the two middle sensors.
*/
void followline(void)
{
        int n = get_line(0) ? 1 : 0;
            n |= get_line(1) ? 2 : 0;
            n |= get_line(2) ? 4 : 0;
            n |= get_line(3) ? 8 : 0;
        checkline(n);
        if(controltaken != 0)
        {
            followNoReadings();
        }
}

/*
    The actions done in Follow mode.
*/
void follow(void)
{
    controltaken = 1;
    wait(1);
    readable3 = 0;
    while((sw1 != 0 && sw2 !=0) && exitfollowing != 1 && defaultMode != 1)
    {
        ble.waitForEvent();
        if(controltaken)
            followline();
    }
    exitfollowing = 0;
    controltaken = 0;
    readable3 = 1;
}

/*
    The actions done in Control while Reading mode.
*/
void controlAndRead(void)
{
    readable3 = 1;
    controlandreading = 1;
    wait(1);
    while(sw1 != 0 && sw2 !=0 && defaultMode != 1)
    {
        int n = readLine();
        checkline(n);
        ble.waitForEvent();
    }
    controlandreading = 0;
}

/*
    The mode is for the robot to follow a road and do actions
    according to the pattern.
*/
void followMode(void)
{
    LED_1 = 0;
    follow();
    statesReset();
    LED_1 = 1;
    PWML = 0;
    PWMR = 0;
}

/*
    The mode is for the robot to read a pattern without doing actions.
*/
void controlAndReadMode(void)
{
    LED_2 = 0;
    controlAndRead();
    statesReset();
    LED_2 = 1;
    PWML = 0;
    PWMR = 0;
}
/*
    main method
*/
int main(void)
{   
    sensor2 = White;
    sensor3 = White;
    LED_2 = 1;
    LED_1 = 1;
    
    Ticker ticker;
    ticker.attach_us(m_status_check_handle, 200000);
    
    ble.init();
    ble.onDisconnection(disconnectionCallback);
    ble.onDataWritten(WrittenHandler);  
    
    pc.baud(9600);
    pc.printf("SimpleChat Init \r\n");
    
    // setup advertising 
    ble.accumulateAdvertisingPayload(GapAdvertisingData::BREDR_NOT_SUPPORTED);
    ble.setAdvertisingType(GapAdvertisingParams::ADV_CONNECTABLE_UNDIRECTED);
    ble.accumulateAdvertisingPayload(GapAdvertisingData::SHORTENED_LOCAL_NAME,
                                    (const uint8_t *)"Wallbot", sizeof("Wallbot") - 1);
    ble.accumulateAdvertisingPayload(GapAdvertisingData::COMPLETE_LIST_128BIT_SERVICE_IDS,
                                    (const uint8_t *)uart_base_uuid_rev, sizeof(uart_base_uuid));
    // 100ms; in multiples of 0.625ms. 
    ble.setAdvertisingInterval(160);

    ble.addService(uartService);
    
    ble.startAdvertising(); 
    
    pc.printf("Advertising Start \r\n");
    
    while(1)
    {
        //sw1 for Follow mode
        if(sw1==0)
        {
            defaultMode = 0;
            followMode();
            if(sw2 == 0)
                controlAndReadMode();
            else
                wait(1);
        }
        
        defaultMode = 1;
        
        //sw2 for Control while Reading mode
        if(sw2==0)
        {
            defaultMode = 0;
            controlAndReadMode();
            if(sw1 == 0)
                followMode();
            else
                wait(1);
        }
        
        defaultMode = 1;
        
        ble.waitForEvent();
    }
}